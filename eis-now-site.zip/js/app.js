(() => {
const $ = s => document.querySelector(s);
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const slug = s => s.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
const store = {
  get: k => { try { return localStorage.getItem(k); } catch (e) { return null; } },
  set: (k, v) => { try { localStorage.setItem(k, v); } catch (e) {} }
};

const ICONS = {
  home: "M3.5 10.5 12 3.5l8.5 7M5.5 9v11h13V9",
  news: "M4 5.5h13v14H6a2 2 0 0 1-2-2zM17 9h3v8.5a2 2 0 0 1-2 2M7.5 9h6M7.5 12.5h6M7.5 16h4",
  crew: "M9 11a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7zM2.5 20a6.5 6.5 0 0 1 13 0M16 4.3a3.5 3.5 0 0 1 0 6.4M18.5 14a6.5 6.5 0 0 1 3 6",
  tip: "M4 6.5h16v11H4zM4 7l8 6 8-6",
  sun: "M12 16.5a4.5 4.5 0 1 0 0-9 4.5 4.5 0 0 0 0 9zM12 2.5v2M12 19.5v2M4.6 4.6l1.4 1.4M18 18l1.4 1.4M2.5 12h2M19.5 12h2M4.6 19.4 6 18M18 6l1.4-1.4",
  moon: "M20.5 14.5A8.5 8.5 0 0 1 9.5 3.5a8.5 8.5 0 1 0 11 11z"
};
const ic = name => `<svg class="ic" viewBox="0 0 24 24" aria-hidden="true"><path d="${ICONS[name]}"/></svg>`;

const NAV = [["#top", "Home", "home"], ["#stories", "Stories", "news"], ["#crew", "Crew", "crew"], ["#contact", "Contact", "tip"]];

const stories = EIS.stories.map(s => ({ ...s, id: slug(s.title) }));
const when = d => new Date(d + "T12:00:00").toLocaleDateString("en-GB", { day: "numeric", month: "long", year: "numeric" });
const initials = n => n.split(/\s+/).map(w => w[0]).slice(0, 2).join("").toUpperCase();

/* ---------- logo: uses assets/logo.png when it is there, the wordmark otherwise ---------- */
const word = `<span class="brand-word">EIS <em>NOW</em></span>`;
$(".brand").innerHTML = word;
$(".side-logo").innerHTML = word;
const logo = new Image();
logo.onload = () => {
  document.documentElement.style.setProperty("--logo", `url("${logo.src}")`);
  document.querySelectorAll(".brand-word").forEach(w => w.remove());
};
logo.src = "assets/logo.png";

/* ---------- content ---------- */
function fill() {
  const { hero, issue, contact } = EIS;
  $("#heroTitle").innerHTML = `${esc(hero.title)}<br><span>${esc(hero.highlight)}</span>`;
  $("#heroLede").textContent = hero.lede;
  const lead = stories[0];
  $("#issueCard").innerHTML = `
    <span class="screen-big">Issue #${esc(issue.number)}</span>
    <span class="screen-sub">${esc(issue.month)}</span>
    ${lead ? `<a class="screen-lead" href="#story/${lead.id}" style="display:block;text-decoration:none"><small>Front page</small>${esc(lead.title)}</a>` : ""}
    <span class="screen-tag">${esc(issue.channel)}</span>`;
  $("#sideIssue").textContent = `Issue #${issue.number} · ${issue.month}`;

  const items = EIS.ticker.map(t => `<span>${esc(t)}</span>`).join("");
  const track = $("#ticker");
  track.innerHTML = items + items;
  track.style.setProperty("--dur", Math.max(24, EIS.ticker.join("").length / 5) + "s");

  $("#crewGrid").innerHTML = EIS.crew.map(m => `
    <div class="glass-card member">
      <span class="avatar">${esc(initials(m.name))}</span>
      <div><p class="role">${esc(m.role)}</p><h4>${esc(m.name)}</h4><p>${esc(m.about)}</p></div>
    </div>`).join("");
  $("#crewCount").textContent = `${EIS.crew.length} people`;

  $("#tipText").textContent = contact.text;
  $("#tipLink").href = `mailto:${contact.email}?subject=${encodeURIComponent("Story tip for EIS NOW")}`;
  $("#year").textContent = new Date().getFullYear();

  const links = NAV.map(([href, label, icon]) => `<a href="${href}">${ic(icon)}<span>${label}</span></a>`).join("");
  $("#sideNav").innerHTML = links;
  $("#bnav").innerHTML = links;
  $("#topNav").innerHTML = NAV.slice(1).map(([href, label]) => `<a href="${href}">${label}</a>`).join("");

  const sections = ["All", ...new Set(stories.map(s => s.section))];
  $("#filters").innerHTML = sections.map((s, i) => `<button type="button" role="tab" aria-selected="${i === 0}" data-section="${esc(s)}">${esc(s)}</button>`).join("");
  showStories("All");
}

function showStories(section) {
  const list = section === "All" ? stories : stories.filter(s => s.section === section);
  $("#storyGrid").innerHTML = list.length ? list.map((s, i) => `
    <a class="glass-card story${i === 0 && section === "All" ? " lead" : ""}" href="#story/${s.id}" style="--i:${i}">
      <span class="tag">${esc(s.section)}</span>
      <h3>${esc(s.title)}</h3>
      <p>${esc(s.summary)}</p>
      <p class="byline">By ${esc(s.author)} · ${when(s.date)}</p>
    </a>`).join("") : `<p class="empty">Nothing in this section yet.</p>`;
}

$("#filters").addEventListener("click", e => {
  const b = e.target.closest("button"); if (!b) return;
  $("#filters").querySelectorAll("button").forEach(x => x.setAttribute("aria-selected", x === b));
  showStories(b.dataset.section);
});

/* ---------- reading a story: #story/<id> ---------- */
const reader = $("#reader");
let lastFocus = null;
function route() {
  const m = location.hash.match(/^#story\/(.+)$/);
  const s = m && stories.find(x => x.id === m[1]);
  if (!s) { if (!reader.hidden) { reader.hidden = true; document.body.style.overflow = ""; lastFocus?.focus(); } return; }
  lastFocus = document.activeElement;
  $("#readerBody").innerHTML = `
    <span class="tag">${esc(s.section)}</span>
    <h1 id="readerTitle">${esc(s.title)}</h1>
    <p class="reader-meta">By ${esc(s.author)} · ${when(s.date)}</p>
    ${(s.body || [s.summary]).map(p => `<p>${esc(p)}</p>`).join("")}`;
  reader.hidden = false;
  document.body.style.overflow = "hidden";
  reader.querySelector(".reader-sheet").scrollTop = 0;
  reader.querySelector(".reader-x").focus();
  document.title = `${s.title} · EIS NOW`;
}
function closeReader() {
  document.title = "EIS NOW";
  if (history.state?.fromList) history.back();
  else history.replaceState(null, "", location.pathname + "#stories"), route();
}
addEventListener("hashchange", route);
document.addEventListener("click", e => {
  const a = e.target.closest('a[href^="#story/"]');
  if (a) { e.preventDefault(); history.pushState({ fromList: true }, "", a.getAttribute("href")); route(); return; }
  if (e.target.closest("[data-close]")) closeReader();
});
addEventListener("popstate", route);
addEventListener("keydown", e => { if (e.key === "Escape" && !reader.hidden) closeReader(); });

/* ---------- light / dark ---------- */
const themeBtn = $("#theme");
function paintTheme() {
  const dark = document.documentElement.dataset.theme !== "light";
  themeBtn.innerHTML = ic(dark ? "sun" : "moon");
  themeBtn.setAttribute("aria-label", dark ? "Light mode" : "Dark mode");
  document.querySelector('meta[name="theme-color"]').content = dark ? "#120A26" : "#F2EEFB";
}
themeBtn.addEventListener("click", () => {
  const next = document.documentElement.dataset.theme === "light" ? "dark" : "light";
  const flip = () => { document.documentElement.dataset.theme = next; store.set("eis-theme", next); paintTheme(); };
  document.startViewTransition ? document.startViewTransition(flip) : flip();
});

/* ---------- which section is on screen ---------- */
const spy = new IntersectionObserver(entries => {
  entries.forEach(en => {
    if (!en.isIntersecting) return;
    const href = en.target.id === "top" || en.target.classList.contains("hero") ? "#top" : "#" + en.target.id;
    document.querySelectorAll(".side-nav a, .bnav a, .top-nav a").forEach(a => a.classList.toggle("on", a.getAttribute("href") === href));
  });
}, { rootMargin: "-45% 0px -50% 0px" });
document.querySelectorAll(".hero, #stories, #crew, #contact").forEach(s => spy.observe(s));

/* ---------- glass that catches the light under the pointer ---------- */
if (matchMedia("(hover: hover) and (pointer: fine)").matches) {
  let lit = null;
  document.addEventListener("pointermove", e => {
    const card = e.target.closest?.(".glass-card");
    if (lit && lit !== card) lit.classList.remove("lit");
    lit = card; if (!card) return;
    const r = card.getBoundingClientRect();
    card.style.setProperty("--mx", e.clientX - r.left + "px");
    card.style.setProperty("--my", e.clientY - r.top + "px");
    card.classList.add("lit");
  }, { passive: true });
}

/* ---------- the little TV-headed people floating down the background ---------- */
const HEAD = `<rect x="15" y="12" width="30" height="22" rx="3"/><path d="M22 12 14 2M38 12l8-10"/>`;
const POSES = [
  "M30 34v36M30 45 10 30M30 45l18 10M30 70 14 96M30 70l16 26",
  "M30 34v36M30 45l25-5M30 45 15 60M30 70 18 96M30 70l12 26",
  "M30 34v34M30 42 10 50M30 42l22-7M30 68 10 90M30 68l18 30",
  "M30 34v36M30 40 12 10M30 40l18-30M30 70 16 96M30 70l14 26",
  "M30 34v36M30 42l12-24M30 42 14 55M30 70 18 96M30 70l12 26"
];
const count = innerWidth < 720 ? 9 : 16;
$("#figures").innerHTML = Array.from({ length: count }, (_, i) => {
  const left = (i / count) * 100 + Math.random() * (100 / count);
  const w = 30 + Math.random() * 28, dur = 16 + Math.random() * 15, delay = -Math.random() * dur;
  const extra = i % POSES.length === 4 ? `<circle cx="42" cy="14" r="4"/>` : "";
  return `<svg viewBox="0 0 60 100" style="left:${left}%;width:${w}px;animation-duration:${dur}s;animation-delay:${delay}s">${HEAD}<path d="${POSES[i % POSES.length]}"/>${extra}</svg>`;
}).join("");

/* ---------- power-on ---------- */
const tv = $("#tv");
function powerSound() {
  const AC = window.AudioContext || window.webkitAudioContext; if (!AC) return;
  const ac = new AC(), t = ac.currentTime, out = ac.createGain();
  out.gain.value = .5; out.connect(ac.destination);

  const thunk = ac.createOscillator(), tg = ac.createGain();
  thunk.type = "sine";
  thunk.frequency.setValueAtTime(140, t); thunk.frequency.exponentialRampToValueAtTime(38, t + .35);
  tg.gain.setValueAtTime(.0001, t); tg.gain.exponentialRampToValueAtTime(.8, t + .02); tg.gain.exponentialRampToValueAtTime(.0001, t + .5);
  thunk.connect(tg).connect(out); thunk.start(t); thunk.stop(t + .6);

  const whine = ac.createOscillator(), wg = ac.createGain();
  whine.frequency.setValueAtTime(6000, t + .3); whine.frequency.linearRampToValueAtTime(9500, t + 1.2);
  wg.gain.setValueAtTime(.0001, t + .3); wg.gain.exponentialRampToValueAtTime(.025, t + 1); wg.gain.exponentialRampToValueAtTime(.0001, t + 4.6);
  whine.connect(wg).connect(out); whine.start(t + .3); whine.stop(t + 4.8);

  const len = ac.sampleRate * 3.4, buf = ac.createBuffer(1, len, ac.sampleRate), data = buf.getChannelData(0);
  for (let i = 0; i < len; i++) data[i] = Math.random() * 2 - 1;
  const hiss = ac.createBufferSource(), band = ac.createBiquadFilter(), hg = ac.createGain();
  hiss.buffer = buf; band.type = "bandpass"; band.frequency.value = 2400; band.Q.value = .6;
  [[1.08, .32], [1.3, .08], [1.6, .36], [1.9, .06], [2.3, .34], [2.65, .1], [3, .3], [3.35, .06], [3.7, .22], [4, .1], [4.3, .0001]]
    .forEach(([at, v], i) => i ? hg.gain.setValueAtTime(v, t + at) : (hg.gain.setValueAtTime(.0001, t), hg.gain.setValueAtTime(v, t + at)));
  hiss.connect(band).connect(hg).connect(out); hiss.start(t + 1); hiss.stop(t + 4.4);

  setTimeout(() => ac.close(), 6000);
}
function powerOn() {
  if (tv.classList.contains("on")) return;
  tv.classList.add("on");
  try { powerSound(); } catch (e) {}
  try { sessionStorage.setItem("eis-tuned", "1"); } catch (e) {}
  setTimeout(() => { tv.remove(); document.body.classList.remove("tuning"); }, 6000);
}
let seen = false;
try { seen = sessionStorage.getItem("eis-tuned") === "1"; } catch (e) {}
if (seen || location.hash.startsWith("#story/")) tv.remove();
else { document.body.classList.add("tuning"); tv.addEventListener("click", powerOn); tv.focus(); }

fill();
paintTheme();
route();
if ("serviceWorker" in navigator && location.protocol === "https:") navigator.serviceWorker.register("sw.js");
})();
