// Everything the site shows lives in this file.
// To add a story, copy one of the { ... } blocks in "stories", paste it at the top of the list and change the text.
// Keep the quotes and the commas between blocks. The first story in the list is the front page.

const EIS = {
  issue: {
    number: 1,
    month: "October 2026",
    channel: "CH. 01"
  },

  hero: {
    title: "Your school,",
    highlight: "right now.",
    lede: "News, sport, events and the stories behind them, written by students for students."
  },

  ticker: [
    "Issue 1 is out now",
    "Science fair winners announced",
    "Basketball team through to the finals",
    "Want to write for us? Room 12, Thursday break"
  ],

  stories: [
    {
      section: "Front page",
      title: "Headline for the main story goes here",
      summary: "A couple of sentences that sum up the story and make people want to read on.",
      author: "Name Surname",
      date: "2026-10-20",
      body: [
        "This is the first paragraph of the full story. Each paragraph goes in its own pair of quotes.",
        "This is the second paragraph. Add as many as you need, with a comma after each one except the last."
      ]
    },
    {
      section: "Sport",
      title: "Second story headline",
      summary: "Short summary of the story.",
      author: "Name Surname",
      date: "2026-10-18",
      body: ["Full text of the story."]
    },
    {
      section: "Events",
      title: "Third story headline",
      summary: "Short summary of the story.",
      author: "Name Surname",
      date: "2026-10-16",
      body: ["Full text of the story."]
    },
    {
      section: "Science",
      title: "Fourth story headline",
      summary: "Short summary of the story.",
      author: "Name Surname",
      date: "2026-10-14",
      body: ["Full text of the story."]
    },
    {
      section: "Opinion",
      title: "Fifth story headline",
      summary: "Short summary of the story.",
      author: "Name Surname",
      date: "2026-10-12",
      body: ["Full text of the story."]
    }
  ],

  crew: [
    { role: "Editor in chief", name: "Name Surname", about: "Runs the paper and signs off every issue." },
    { role: "Deputy editor", name: "Name Surname", about: "Plans the stories and keeps deadlines." },
    { role: "Reporter", name: "Name Surname", about: "Covers sport and school events." },
    { role: "Photographer", name: "Name Surname", about: "Takes the photos for every issue." }
  ],

  contact: {
    text: "Seen something the school should know about? Tell us and we might run it.",
    email: "eisnow@example.com"
  }
};
