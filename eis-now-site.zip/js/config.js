// The Supabase project that stores the stories: Project Settings → API.
// Both values are safe to have in public; the editor code is what protects editing.
const CLOUD = {
  url: "",
  key: ""
};
