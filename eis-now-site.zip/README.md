# EIS NOW

The website for EIS NOW, the student newspaper.

Plain HTML, CSS and JavaScript. No build step, nothing to install.

```
index.html            page layout
css/site.css          all the styling
js/stories.js         the content: issue, ticker, stories, crew, contact
js/app.js             intro, menus, story reader, light/dark switch
assets/               logo and icons
manifest.webmanifest  lets people add it to their home screen
sw.js                 keeps a saved copy for when there's no signal
```

## Changing the content

Everything people read is in `js/stories.js`. You never need to touch the other files.

On GitHub:

1. Open `js/stories.js` and click the pencil icon (Edit this file).
2. Change the text between the quotes.
3. Click **Commit changes**. The site updates by itself in about a minute.

To add a story, copy a whole block from `{` to `},`, paste it at the top of the `stories` list and change the words. The top story is always the front page.

```js
{
  section: "Sport",
  title: "The headline",
  summary: "One or two sentences shown on the card.",
  author: "Name Surname",
  date: "2026-10-25",
  body: [
    "First paragraph.",
    "Second paragraph."
  ]
},
```

Things that break the page:

- a missing comma between two stories
- a quote mark inside the text; write `it's` fine, but for a quote inside a sentence use ‘curly’ quotes or `\"`
- deleting a `[` `]` `{` or `}`

If the page goes blank after an edit, open the file's **History** on GitHub and look at the last change. Undoing it brings the site back.

New issue: change `number` and `month` under `issue`, and swap the stories.

## The logo

Put the logo in `assets/` named `logo.png`. The site picks it up on its own; until then it shows the EIS NOW wordmark.

## Hosting

The site runs on GitHub Pages: repository **Settings → Pages → Deploy from a branch → main / (root)**.
